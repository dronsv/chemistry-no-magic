
# Reaction Layer v1

## Purpose

This layer models reactions as structured entities with participant roles.
It enables n-ary relations such as:
- Substance as catalyst in a specific reaction
- Oxidizing/reducing agents
- Gas evolution and precipitate formation

## Structure

- reactions.v1.json — reaction registry
- reaction_roles.v1.json — allowed participant roles
- reaction_participants.v1.json — n-ary participation records

## Design Principles

1. Roles are contextual to a reaction.
2. Catalyst is NOT a property of substance globally.
3. Inverse lookups (which reactions use Pt as catalyst) are build-time indexes.

## Educational Use

Supports automatic generation of tasks:
- Identify catalyst
- Determine oxidizing agent
- Select substances not participating
- Build reaction chains with conditions
