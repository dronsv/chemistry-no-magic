# decomposition_drivers_layer_v1_package

Contains:
- processes/decomposition.v1.json
- drivers/drivers.v1.json
- conditions/conditions.v1.json
- rules/ (3 example rules)
- translations/ru/decomposition_drivers.v1.json (template-based strings)
- docs/decomposition_drivers_layer_v1.md

Goal:
Model decomposition as (process + driver + rule), not as separate hardcoded processes per cause.
