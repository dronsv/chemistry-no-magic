/** Core identifiers */
export type OntId = string
export type EduId = string
export type ArtifactId = string

/** Domain concept kinds */
export type DomainConceptKind =
  | 'concept'
  | 'property_concept'
  | 'quantity_concept'
  | 'class'
  | 'reaction_type'
  | 'formula_concept'

/** Didactic levels */
export type DidacticLevel = 'basic' | 'core' | 'advanced' | 'olympiad'

/** Presentation mode for ontology embedding */
export type OntPresentationKind = 'OntRef' | 'OntDef' | 'OntBlock'

/** Characteristic value provenance */
export type ValueSourceKind = 'asserted' | 'derived' | 'approximate'

/** Conditions for context-dependent quantities */
export type ConditionContext = {
  solvent?: string
  temperature_C?: number
  pressure_kPa?: number
  dissociation_step?: number
  ionic_strength?: number
  phase?: 'solid' | 'liquid' | 'gas' | 'aqueous'
  context_tag?: 'canonical_aq_25C' | 'standard_school' | string
}

/** Units */
export type UnitCode = string

/** Canonical domain concept */
export type DomainConcept = {
  id: OntId
  kind: DomainConceptKind
  canonical_name: string
  short_definition?: string
  full_definition?: string
  related_concepts?: OntId[]
  explained_by?: OntId[]
}

/** Typed characteristic attached to an entity or concept */
export type TypedCharacteristic = {
  id: string
  characteristic_concept_id: OntId
  /** what object this characteristic belongs to */
  subject_id: string
  value_kind: 'number' | 'string' | 'boolean' | 'enum' | 'formula' | 'range'
  value:
    | number
    | string
    | boolean
    | { code: string; label?: string }
    | { expr: string }
    | { min?: number; max?: number }
  unit?: UnitCode
  conditions?: ConditionContext
  source?: {
    kind: ValueSourceKind
    ref?: string
    derived_from?: string[]
  }
  confidence?: 'high' | 'medium' | 'low'
  explanation_concept_id?: OntId
  notes?: string
}

/** Didactic concept */
export type EduConcept = {
  id: EduId
  title: string
  level: DidacticLevel
  learning_goal?: string
  references_domain_concepts: OntId[]
  prerequisites?: EduId[]
  deepens?: EduId[]
}

/** Topic/course element */
export type EduTopicElement = {
  id: EduId
  kind: 'topic' | 'module' | 'lesson' | 'didactic_block' | 'question' | 'task'
  title: string
  level: DidacticLevel
  contains?: Array<TextBlock | OntEmbed | ExampleBlock | QuestionBlock | TaskBlock>
  references_domain_concepts?: OntId[]
  references_edu_concepts?: EduId[]
}

export type TextBlock = {
  type: 'text'
  markdown: string
}

export type ExampleBlock = {
  type: 'example'
  title: string
  markdown: string
  references_domain_concepts?: OntId[]
}

export type QuestionBlock = {
  type: 'question'
  question_id: ArtifactId
  prompt: string
  tests_edu_concepts?: EduId[]
  requires_domain_concepts?: OntId[]
}

export type TaskBlock = {
  type: 'task'
  task_id: ArtifactId
  title: string
  tests_edu_concepts?: EduId[]
  requires_domain_concepts?: OntId[]
}

/** Embedded ontology item inside course content */
export type OntEmbed = {
  type: 'ont_embed'
  concept_id: OntId
  mode: OntPresentationKind
  didactic_level?: DidacticLevel
  override_title?: string
  override_short_def?: string
  include?: {
    formula?: boolean
    example?: boolean
    rabbit_hole?: boolean
    prerequisites?: boolean
    related_characteristics?: boolean
  }
}
