# Пакет 2. Формальная модель темы курса «Кислоты»

Состав пакета:

- `01_ARCHITECTURE_OVERVIEW.md` — краткая формальная архитектура
- `02_TYPES.ts` — TypeScript-типы для domain/didactic/embedding/characteristics
- `03_JSON_SCHEMA_EXAMPLES.json` — примеры JSON-структур
- `04_EDU_TOPIC_ACIDS.example.json` — пример `edu:topic_acids`
- `05_ONT_EMBED.example.json` — примеры `ont_embed`
- `06_TYPED_CHARACTERISTICS.example.json` — примеры типизированных характеристик
- `07_INFERENCE_NOTES.md` — как это упрощает вывод и explainability
- `08_AUTHORING_RULES.md` — правила авторинга

Цель пакета — зафиксировать не только содержательную модель темы «Кислоты», но и формальный слой, пригодный для реализации в коде и для дальнейшего механизма вывода.
