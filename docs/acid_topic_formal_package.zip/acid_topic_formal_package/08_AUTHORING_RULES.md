# Правила авторинга

## 1. Если в материале показана характеристика, она должна быть типизирована

Нельзя:
- просто написать «электроотрицательность 3.16»;
- просто написать «масса 18»;
- просто написать «Ka = 1.8e-5».

Нужно:
- указать онтологический концепт характеристики;
- при необходимости указать единицы;
- при необходимости указать условия;
- дать путь к объяснению.

## 2. Рекомендуемые ссылки

- масса / молярная масса → `concept:molar_mass`
- электроотрицательность → `concept:electronegativity`
- энергия ионизации → `concept:ionization_energy`
- константа кислотной диссоциации → `concept:acid_dissociation_constant`
- `pKa` → `concept:pKa`
- основность кислоты → `concept:acid_basicity`

## 3. Для темы «Кислоты» обязательные ont embeds

### Минимум
- `cls:acid`
- `concept:acid_strength`
- `concept:acid_basicity`
- `concept:acid_dissociation_constant`
- `concept:pKa`
- `concept:conjugate_base`

### Для углубления
- `concept:free_energy_change`
- `concept:bond_strength_H_A`
- `concept:charge_delocalization`
- `concept:inductive_effect`
- `concept:anion_size_polarizability`
- `concept:solvation`

## 4. Правило объяснимости

Если характеристика показана пользователю, должен существовать хотя бы один из вариантов:
1. `OntRef` на её концепт;
2. `OntDef` с кратким определением;
3. `OntBlock` с полноценным объяснением.

## 5. Правило для контекстно-зависимых величин

Для `Ka`, `pKa` и других контекстно-зависимых величин нужно хранить условия.

Если условия не указаны, используется канонический учебный контекст по умолчанию.
