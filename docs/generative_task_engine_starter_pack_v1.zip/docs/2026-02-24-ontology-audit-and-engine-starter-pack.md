# Аудит онтологии и готовности к Generative Task Engine

**Источник:** data-src.zip (развернут в `data-src/`)

**Дата:** 2026-02-24


---

## 1. Краткий вывод

Онтология уже содержит ядро (элементы, ионы, вещества, реакции, правила, шаблоны), достаточное для запуска **первых data-driven шаблонов** (periodic + oxidation + базовые ионные/растворимость). Для полноценной генерации реакций и строгих ионных уравнений не хватает явных полей (фаза/электролитность) и нормализованных ruleset-правил на уровне `ion.id`.


---

## 2. Инвентаризация (что реально есть в data-src)

- Всего файлов: **195**

- elements.json: **118** элементов

- ions.json: **31** ион

- substances/*.json: **80** веществ

- rules/*.json: **16** наборов правил

- templates/*.json: **2** файла (task_templates + reaction_templates)

- translations: локали **en, es, pl**


### 2.1 elements.json — поля

Содержит не только учебные поля (группа/период/ЭО/типичные СО), но и физ. свойства и контентные тексты (опасности, применение, факты).

Ключевые поля: `Z, symbol, group, period, electronegativity, typical_oxidation_states, atomic_mass, melting_point_C, boiling_point_C, density_g_cm3, electron_exception`.


### 2.2 ions.json — поля

Содержит `id`, `formula`, `charge`, `type`, `tags`, а также RU-родительный падеж `name_ru_genitive` (важно для авто-генерации текста).


### 2.3 substances/*.json — поля

Вещества уже содержат `class`, `subclass`, `ions`, `tags`, но **не имеют** явных полей: `phase`, `electrolyte_strength`.


---

## 3. Что хорошо подходит под Generative Task Engine уже сейчас

### 3.1 Периодические свойства

- Можно генерировать сравнение/упорядочивание по `electronegativity`, `atomic_mass`, `melting_point_C`, `boiling_point_C`, `density_g_cm3`.

- Для задач уровня ОГЭ достаточно 3–4 элемента из одного периода/группы (генераторы `pick_elements_same_period/group`).


### 3.2 Степени окисления

- В `elements.json` есть `typical_oxidation_states`, а в `templates/reaction_templates.json` уже есть заготовки реакций.

- На Phase 1 можно использовать **набор примеров** (как в design-doc) либо вычислять СО из формулы при наличии парсера.


### 3.3 Растворимость (пока в виде таблицы)

- `rules/solubility_rules_light.json` содержит 108 пар (катион/анион/растворимость). Это позволяет делать solver `solubility_check`, но требует нормализации в `ion.id`.


---

## 4. Основные пробелы (что нужно добавить/нормализовать)

### 4.1 Solubility ruleset: перейти на ion.id

Сейчас пары записаны строками формул (`Na⁺`, `Cl⁻`). Для генераторов/solver'ов лучше хранить:

- `cation: Na_plus`, `anion: Cl_minus` (из `ions.json`)

- версионирование ruleset (`solubility.*.v1`)


**Сделано в примере:** `solubility.light_pairs.v1.json` (см. приложенные файлы).


### 4.2 Фаза и электролитность веществ

Для ионных уравнений, 'идёт/не идёт', осадок/газ/вода нужно явное:

- `phase: s|aq|l|g`

- `electrolyte_strength: strong|weak|none`

Часть можно вывести из класса/тегов, но явное поле дешевле в поддержке и проще в solver'ах.


### 4.3 Словарь свойств (properties.json)

Для мультиязычности и универсального `compare_property/order_by_property` нужен единый словарь свойств:

- `id`
- откуда брать числовое значение (`value_field`)
- единицы
- локализация (ru/en/…)


**Сделано в примере:** `properties.v1.json`.


### 4.4 Морфология RU (минимальный seed)

У ионов есть genitive, у элементов — нет. Для RU достаточно (Phase 1):

- `nom`, `gen`, `gender` для топ-частотных элементов и свойств


**Сделано в примере:** `morphology.ru.seed.v1.json`.


---

## 5. Рекомендованная схема файлов для engine (совместима с design-doc)

Минимум для запуска первых 5 шаблонов:

1) `rules/properties.json`
2) `rules/solubility_rules.json` (ruleset или пары на `ion.id`)
3) `prompt_templates/{ru,en}.json`
4) `translations/ru/morphology.json` (seed)
5) `task_templates/engine/*.json` (pipeline templates)


---

## 6. Стартовый пакет engine-templates (пример)

Сгенерирован файл `task_templates.engine.v1.json` (5 шаблонов):

- `tmpl.pt.compare_property.v1`
- `tmpl.pt.order_by_property.v1`
- `tmpl.ox.determine_state.v1`
- `tmpl.ion.compose_salt.v1`
- `tmpl.sol.check_pair.v1`


Это демонстрационные шаблоны под вашу целевую архитектуру (generator/solver/renderer/prompt/evidence/difficulty).


---

## 7. UX заметки (desktop/mobile) — что зафиксировать в движке

### 7.1 order_dragdrop
- Desktop: горизонтальная полоса, drag&drop
- Mobile: вертикальный reorder, автоскролл, крупные зоны захвата (≥44px)
- Partial credit: score по позиции элементов


### 7.2 numeric_input
- Mobile: одна сущность на экран, крупная клавиатура, автоподстановка знака (+) по умолчанию
- Обязательно: валидация диапазона, подсветка ошибки без 'красного экрана'


### 7.3 formula_input (Phase 2+)
- Нужен визуальный билдер (выбор элемента, индекс, скобки)
- Ручной ввод должен быть опцией, но не основным путём


---

## 8. Приоритетный план работ (минимально достаточный)

**P0 (блокер для реакций/ионных):**
1) Нормализовать растворимость на `ion.id` + версионирование ruleset
2) Добавить `phase` и `electrolyte_strength` в вещества (хотя бы для топ-50)


**P1 (движок):**
3) Завести `properties.json`
4) Завести `prompt_templates` для 10–15 фраз
5) Seed морфологии RU (nom/gen)


**P2 (качество):**
6) `error_models.json` для 5 архетипов
7) Автотест: генерация 10k задач на шаблон без невалидных



---

## 9. Приложенные артефакты

- `properties.v1.json`

- `solubility.light_pairs.v1.json`

- `task_templates.engine.v1.json`

- `prompt_templates.ru.v1.json`

- `prompt_templates.en.v1.json`

- `morphology.ru.seed.v1.json`


---

## 10. Примечание о совместимости

Эти файлы — **пример структуры**, совместимой с вашим design-doc. Они не ломают текущую архитектуру и могут лежать параллельно с существующими генераторами до полной миграции.
