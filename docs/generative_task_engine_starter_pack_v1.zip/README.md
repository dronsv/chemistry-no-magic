# Generative Task Engine – Starter Package v1

## Structure

rules/
  properties.v1.json
  solubility.light_pairs.v1.json

templates/engine/
  task_templates.engine.v1.json

prompts/
  ru/prompt_templates.v1.json
  en/prompt_templates.v1.json

morphology/
  ru/morphology.seed.v1.json

docs/
  2026-02-24-ontology-audit-and-engine-starter-pack.md

## Purpose

This package provides:

- Normalized property dictionary
- Solubility ruleset using ion.id
- Engine-ready task templates (pipeline-based)
- Multilingual prompt templates (RU/EN)
- Russian morphology seed (nom/gen)
- Ontology audit report

Designed to integrate with Generative Task Engine architecture.
