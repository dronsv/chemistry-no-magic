# Ontology Agent Prompts Package

Пакет prompt/spec файлов для набора агентов онтологизации.

## Состав
- `ontology-architect.md`
- `ontology-extractor.md`
- `ontology-enrichment.md`
- `ontology-localizer.md`
- `ontology-auditor.md`
- `ontology-write-operator.md`
- `ontology-agent-orchestration.md`

## Важный принцип
Во всех агентах предполагается наличие **ontology MCP** как основного рабочего интерфейса к онтологии.

Это означает:

- поиск существующих сущностей делается через MCP tools;
- проверка дублей делается через MCP;
- bootstrap / resolve / validate делаются через MCP;
- write changes по возможности идут через MCP write tools;
- прямое редактирование файлов допустимо только там, где это явно разрешено процессом и где нет более безопасного MCP-пути.

## Общая дисциплина
1. Сначала использовать existing refs через MCP lookup.
2. Не создавать новую core entity, если хватает relation / overlay / extension.
3. Для medium/high-risk изменений сначала proposal, потом write.
4. После enrichment запускать audit.
