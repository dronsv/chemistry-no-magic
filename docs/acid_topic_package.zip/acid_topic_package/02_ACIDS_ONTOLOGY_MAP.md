# Карта онтологических элементов для темы «Кислоты»

## 1. Центральный предметный каркас

### Класс
- `cls:acid`

### Базовые свойства и концепты
- `concept:acid_strength`
- `concept:acid_basicity`
- `concept:acid_dissociation`
- `concept:acid_dissociation_constant`
- `concept:pKa`
- `concept:conjugate_base`
- `concept:acid_residue`

### Связанные концепты
- `concept:indicator`
- `concept:chemical_equilibrium`
- `concept:free_energy_change`
- `concept:bond_strength`
- `concept:charge_delocalization`
- `concept:inductive_effect`
- `concept:solvation`
- `concept:anion_size`
- `concept:anion_polarizability`
- `concept:electronegativity`
- `concept:ionization_energy`
- `concept:molar_mass`

### Реакции
- `rxtype:acid_metal`
- `rxtype:acid_base`
- `rxtype:acid_base_oxide`
- `rxtype:acid_carbonate`

## 2. Основные связи

### Для базового уровня
- `cls:acid described_by concept:acid_strength`
- `cls:acid has_property concept:acid_basicity`
- `cls:acid participates_in concept:acid_dissociation`
- `concept:acid_dissociation described_by concept:acid_dissociation_constant`
- `concept:acid_dissociation_constant related_to concept:pKa`
- `cls:acid forms concept:acid_residue`
- `cls:acid reacts_via rxtype:acid_metal`
- `cls:acid reacts_via rxtype:acid_base`
- `cls:acid reacts_via rxtype:acid_base_oxide`
- `cls:acid reacts_via rxtype:acid_carbonate`

### Для углубления
- `concept:acid_strength described_by concept:acid_dissociation_constant`
- `concept:acid_dissociation_constant related_to concept:chemical_equilibrium`
- `concept:acid_dissociation_constant related_to concept:free_energy_change`
- `concept:acid_strength depends_on concept:bond_strength`
- `concept:acid_strength depends_on concept:conjugate_base`
- `concept:acid_strength depends_on concept:charge_delocalization`
- `concept:acid_strength depends_on concept:inductive_effect`
- `concept:acid_strength depends_on concept:solvation`
- `concept:acid_strength depends_on concept:anion_polarizability`

## 3. Карта обязательных didactic transitions

- `edu:acids_basic_definition -> edu:acid_strength_basic`
- `edu:acid_strength_basic -> edu:acid_basicity`
- `edu:acid_basicity -> edu:polyprotic_stepwise_dissociation`
- `edu:polyprotic_stepwise_dissociation -> edu:acid_dissociation_constant_ka`
- `edu:acid_dissociation_constant_ka -> edu:pka_as_log_scale`
- `edu:acid_dissociation_constant_ka -> edu:acid_strength_energy_basis`
- `edu:acid_strength_energy_basis -> edu:acid_family_trends`

## 4. Обязательная логика для многоосновных кислот

Если кислота многоосновная, тема обязана связывать:

- `concept:acid_basicity`
- `concept:stepwise_dissociation`
- `concept:Ka_step`
- `concept:acid_residue`

Рекомендуемые связи:

- `concept:acid_basicity determines concept:stepwise_dissociation`
- `concept:stepwise_dissociation described_by concept:Ka_step`
- `concept:stepwise_dissociation forms concept:acid_residue`

## 5. Карта типизированных характеристик

Если в теме или на карточках показываются характеристики, они должны ссылаться на собственные concept nodes, например:

- масса / молярная масса -> `concept:molar_mass`
- электроотрицательность -> `concept:electronegativity`
- энергия ионизации -> `concept:ionization_energy`
- сила кислоты -> `concept:acid_strength`
- `Ka` -> `concept:acid_dissociation_constant`
- `pKa` -> `concept:pKa`
- энергия связи -> `concept:bond_strength`
- поляризуемость -> `concept:anion_polarizability`

## 6. Карта примеров для rabbit hole

### Галогеноводороды
- `substance:HF`
- `substance:HCl`
- `substance:HBr`
- `substance:HI`

### Оксокислоты
- `substance:HClO`
- `substance:HClO2`
- `substance:HClO3`
- `substance:HClO4`

### Карбоновые кислоты
- `substance:CH3COOH`
- `substance:ClCH2COOH`
- `substance:CCl3COOH`

Эти примеры используются не только как вещества, но и как узлы объяснения трендов кислотности.
