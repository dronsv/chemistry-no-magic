# relations_layer_v1 (package)

This package introduces a minimal typed-edge relation layer:

- `relations/predicates.v1.json` — stable predicate vocabulary (≤ 25)
- `relations/relations.examples.v1.json` — examples of edges
- `docs/relations_layer_v1_ru.md` — motivation + integration notes (RU)
- `docs/predicates_catalog_v1_ru.md` — concise predicate list (RU)
- `schemas/relations_schema.md` — lightweight edge schema

Design goals:
- forward edges only; inverses derived
- numeric properties preferred over pairwise comparisons
- conditions for context-dependent chemistry
