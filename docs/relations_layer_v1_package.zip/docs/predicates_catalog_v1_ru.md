# Каталог предикатов v1 (кратко)

Источник: `relations/predicates.v1.json`

## Taxonomy
- is_instance_of
- is_subclass_of
- member_of_group (inverse derived: has_member)

## Composition / Structure
- has_component (inverse derived: component_of)
- composed_of_element (derived from formula parsing)
- has_allotrope / allotrope_of

## Properties
- has_property
- has_numeric_property

## Process / Reaction
- participates_in_process
- has_surface_layer (contextual, use conditions)
- reacts_with (store rarely; prefer solver)
- produces (inverse derived: produced_by)
- requires_condition
- blocks_reaction_family
- inhibits (inverse derived: inhibited_by)

## Context (bridges to contexts layer)
- phase_of
- solution_of
- mixture_of
- melt_of
