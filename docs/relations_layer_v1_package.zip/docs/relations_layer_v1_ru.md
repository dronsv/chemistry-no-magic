# Слой отношений (Relations Layer) v1 — зачем он нужен и как использовать

## 1. Зачем это нужно

Если хранить знания только “внутри сущностей” (elements/substances/rules), то:

- сложно делать универсальный поиск (“кто является аллотропом углерода?”)
- сложно строить генерацию задач по паттернам (“кто пассивируется на воздухе?”)
- невозможно нормально связывать *процессы* и *последствия* (как “оксидная плёнка блокирует реакцию”)
- появляется соблазн дублировать информацию в виде текстов (“покрывается оксидной плёнкой”) — это ломает мультиязычность

Relations layer вводит формальные **типизированные ребра**: subject–predicate–object (+conditions).

## 2. Важный принцип: двусторонность НЕ храним, а выводим

Пример:

- в данных: `el:Cl member_of_group group:halogens`
- в индексе (build): `group:halogens has_member el:Cl`

Это исключает расхождения и уменьшает объём.

## 3. Что хранить, а что вычислять

### Храним
- таксономию (is_instance_of, is_subclass_of, member_of_group)
- качественные свойства (has_property)
- состав (has_component)
- структурные варианты (has_allotrope / allotrope_of)
- процессные знания (participates_in_process, has_surface_layer, blocks_reaction_family)

### НЕ храним явно
- “больше/меньше” для свойств типа EN/IE/радиус — это вычисляется по числам
- обратные связи — строятся билдом

## 4. Минимальный перечень отношений (v1)

Стабильное ядро (рекомендуется держать ≤ 20 предикатов):

### Таксономия
- is_instance_of
- is_subclass_of
- member_of_group (inverse: has_member, derived)

### Состав/структура
- has_component (inverse: component_of, derived)
- has_allotrope / allotrope_of

### Свойства
- has_property
- has_numeric_property

### Процессы/реакции
- participates_in_process
- has_surface_layer (с conditions)
- reacts_with (редко хранить, лучше через solver)
- produces / produced_by (produced_by derived)
- requires_condition
- blocks_reaction_family
- inhibits / inhibited_by (derived)

### Контекстные ссылки (для layers contexts/variants)
- phase_of
- solution_of
- mixture_of
- melt_of

## 5. Пример: “покрывается оксидной плёнкой” (пассивация)

Вместо текста в element-card, хранится ребро:

```json
{
  "subject": "sub:Al",
  "predicate": "has_surface_layer",
  "object": "sub:Al2O3",
  "conditions": {"environment":"air","temperature":"ambient"},
  "evidence": ["proc:passivation","rule:passivation.metals.in_air.v1"]
}
```

А UI может:
- показывать в карточке “пассивация” как факт с условиями
- использовать в генераторе задач (“почему Al не реагирует с водой?”)

## 6. Как это стыкуется с генеративными задачами

Relations layer нужен для двух вещей:
1) **выбор кандидатов** (металлы, которые пассивируются; аллотропы; смеси)
2) **объяснения/дистракторы** (почему реакция не идёт; какие условия нужны)

## 7. Build-time индексы (рекомендуется)

- `inverse_edges.json` (derived inverses)
- `subject_index.json` (subject → edges)
- `object_index.json` (object → edges)
- `reverse_term_index` (уже есть для contexts/variants)

Это ускоряет поиск в UI и генераторе.

