# relations.v1 — Lightweight Schema

This project intentionally avoids heavyweight RDF/OWL at Phase 0.
We define a simple *typed edges* model.

## Edge record

```json
{
  "id": "rel:<unique>",
  "subject": "<node-id>",
  "predicate": "<predicate-id>",
  "object": "<node-id or structured object>",
  "conditions": { "...": "..." },     // optional
  "evidence": ["<ids...>"],           // optional
  "confidence": 0.0-1.0               // optional
}
```

## Design rules

- Store *forward* edges only. Inverses are derived during build.
- Prefer numeric properties over pairwise greater/less edges.
- Use `conditions` for context-dependent chemistry (passivation, solubility, medium).
- Keep predicate vocabulary small (10–20) and stable.
