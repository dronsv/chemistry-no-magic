# Atomic Structure Core Package

Содержимое пакета:

- `ontology.atomic-structure-core.md` — описание скоупа и семантики;
- `concepts.atomic-structure.json` — новые concept-узлы;
- `characteristics.atomic-structure.json` — характеристики;
- `relations.atomic-structure.json` — отношения;
- `laws.atomic-structure.json` — законы/формулы;
- `isotopes.seed.json` — стартовые примеры изотопов;
- `rules.atomic-structure.md` — инварианты и правила валидации;
- `ts-types.atomic-structure.ts` — TS union types.

## Предлагаемый следующий пакет

`orbitals-and-electronic-structure`:

- electron shell;
- orbital;
- subshell;
- spin;
- quantum numbers;
- electron configuration;
- Aufbau / Hund / Pauli.
