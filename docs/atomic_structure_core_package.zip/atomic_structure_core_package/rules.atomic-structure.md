# Atomic Structure Rules

## Core invariants

### Rule 1. Element identity
`atomic_number = proton_count`

### Rule 2. Mass number
`mass_number = proton_count + neutron_count`

### Rule 3. Neutral atom
For a neutral atom: `electron_count = proton_count`

### Rule 4. Isotopic identity
Isotopes of the same element share the same `proton_count`.

### Rule 5. Isotopic difference
Isotopes of the same element differ by `neutron_count` and usually by mass.

## Validation notes

- `char:atomic_number` and `char:proton_count` should never diverge.
- `char:mass_number` should be derivable from proton and neutron counts.
- `char:electron_count` should be omitted or treated separately for ions when the species is not neutral.
