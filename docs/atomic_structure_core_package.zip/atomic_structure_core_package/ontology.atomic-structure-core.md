# Atomic Structure Core

## Цель

Ввести минимальный domain/core для тем:

- строение атома;
- состав ядра;
- изотопы;
- базовые количественные характеристики;
- энергия как физический концепт, необходимый для атомной структуры.

Этот пакет **не** покрывает пока:

- орбитали;
- спин;
- квантовые числа;
- волновую модель;
- тонкую квантовую механику;
- полную термодинамику;
- полную ядерную физику.

## Новые ontology kinds

### Добавить в `OntRefKind`

```ts
export type OntRefKind =
  | 'element'
  | 'substance'
  | 'ion'
  | 'reaction'
  | 'substance_class'
  | 'element_group'
  | 'reaction_type'
  | 'reaction_feature'
  | 'concept'
  | 'isotope'
  | 'law'
```

### Обоснование

- `isotope` нужен как самостоятельный domain kind, а не просто как общий `concept`, потому что изотопы — реальные онтологические сущности с параметрами.
- `law` нужен для формульных и закономерностных узлов вроде `E = m * c^2`, чтобы не смешивать закон с объектом мира.

## Новые `concept:*`

```ts
export type AtomicStructureConceptId =
  | 'concept:electron'
  | 'concept:proton'
  | 'concept:neutron'
  | 'concept:atom'
  | 'concept:atomic_nucleus'
  | 'concept:isotope'
  | 'concept:atomic_number'
  | 'concept:mass_number'
  | 'concept:proton_count'
  | 'concept:neutron_count'
  | 'concept:electron_count'
  | 'concept:nucleon_count'
  | 'concept:charge'
  | 'concept:mass'
  | 'concept:energy'
  | 'concept:energy_level'
  | 'concept:binding_energy'
```

## Новые `law:*`

```ts
export type AtomicStructureLawId =
  | 'law:mass_energy_equivalence'
```

## Новые `rel:*`

```ts
export type AtomicStructureRelationId =
  | 'rel:has_part'
  | 'rel:part_of'
  | 'rel:contains_particle'
  | 'rel:isotope_of'
  | 'rel:defined_by_proton_count'
  | 'rel:characterized_by'
  | 'rel:has_energy_level'
  | 'rel:governed_by'
```

## Новые `characteristic:*`

```ts
export type AtomicStructureCharacteristicId =
  | 'char:charge_in_elementary_units'
  | 'char:mass_kg'
  | 'char:relative_mass_u'
  | 'char:atomic_number'
  | 'char:mass_number'
  | 'char:proton_count'
  | 'char:neutron_count'
  | 'char:electron_count'
  | 'char:is_radioactive'
```

## Семантические инварианты

1. Элемент определяется числом протонов: `atomic_number = proton_count`.
2. Массовое число равно сумме протонов и нейтронов: `mass_number = proton_count + neutron_count`.
3. Для нейтрального атома `electron_count = proton_count`.
4. Изотопы одного элемента имеют одинаковое число протонов.
5. Изотопы одного элемента отличаются числом нейтронов и, как правило, массой.

## Границы пакета

### Входит

- состав атома;
- ядро;
- частицы;
- изотопы;
- числовые характеристики;
- общий concept энергии;
- concept энергетического уровня.

### Не входит пока

- orbital / shell / subshell;
- spin;
- quantum number;
- Pauli / Hund / Aufbau;
- excitation / photon emission;
- mass defect;
- nuclear binding energy;
- ionization energy.
