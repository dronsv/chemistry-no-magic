# Data Governance Matrix (Template + Guidance)
Generated: 2026-02-26

## Goal
Make `docs/ontology-map.md` operational:
- What is source of truth?
- What is derived?
- What regenerates what?
- What needs validation?

---

# 1. Recommended matrix columns

| Artifact | Location | Type | Source of Truth | Derived From | Regenerable | Used By | Validator | Change Impact |
|---------|----------|------|-----------------|--------------|-------------|---------|----------|--------------|

Type ∈ {source-json, build-derived, runtime-derived, docs}

Regenerable:
- yes: can be rebuilt from sources
- no: must be edited manually

Change Impact:
- downstream artifacts to regenerate / caches to invalidate

---

# 2. Example rows (adapt to your repo)

| Artifact | Location | Type | Source of Truth | Derived From | Regenerable | Used By | Validator | Change Impact |
|---------|----------|------|-----------------|--------------|-------------|---------|----------|--------------|
| elements.json | data-src/elements.json | source-json | yes | — | no | engine, UI | validate.mjs | invalidates bundle hash |
| formula_lookup.json | public/data/{hash}/formula_lookup.json | build-derived | no | elements+substances+ions | yes | engine | integrity.mjs | rebuild indices |
| search_index.ru.json | public/data/{hash}/search_index.ru.json | build-derived | no | terms+names+overlays | yes | UI search | validate.mjs | rebuild per locale |
| exam topic mapping | data-src/rules/topic_mapping.json | source-json | yes | — | no | exam mode | validate.mjs | impacts exam→competency selection |

---

# 3. Integration into ontology-map.md
Add a dedicated section:
- “Governance Matrix”
- “Validation & Integrity” (link to existing scripts)
- “Build-time outputs” (what is copied vs generated)

---

# 4. Minimal completeness definition
Matrix must include:
- all `data-src/**` sources
- all build outputs listed in ontology-map.md
- engine templates + prompt templates
- exam banks + topic mapping files
