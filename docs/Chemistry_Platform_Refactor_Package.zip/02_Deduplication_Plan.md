# Deduplication Plan — Single Source Algorithms
Generated: 2026-02-26

## Objective
Eliminate algorithm duplication across:
- `src/lib/*`
- engine `solvers.ts`
- legacy feature generators

Target state: **one implementation per algorithm**, accessed via stable TS function APIs.

---

# 1. Proposed consolidation location

```
src/lib/chem/
  electron-config.ts
  oxidation-state.ts
  bonding/
    delta-chi.ts
    bond-type.ts
  formula/
    parse.ts (optional)
    compose-salt.ts
  stoichiometry/
    molar-mass.ts
    solution.ts
  index.ts
```

All modules must be:
- pure functions (no IO, no global state)
- deterministic
- testable with fixtures

---

# 2. Recommended direction of dependencies

```mermaid
flowchart LR
  ChemLib["src/lib/chem/*"] --> EngineSolvers["engine solvers (adapters)"]
  ChemLib --> Legacy["legacy generators (temporary)"]
  EngineSolvers --> Engine["task engine runtime"]
```

Rule: engine solvers **may** keep orchestration, but must not re-implement math/chem logic if ChemLib owns it.

---

# 3. Concrete duplication fixes

## 3.1 Electron configuration
- Exists in: lib electron-config and engine solveElectronConfig()
- Fix:
  1. Canonical algorithm in `src/lib/chem/electron-config.ts`
  2. Engine solver becomes adapter (validate → call → shape output)

## 3.2 Bond delta-chi / bond calculator
- Exists in: lib bond-calculator, engine solveDeltaChi, legacy bonds generator
- Fix:
  1. Canonical: `src/lib/chem/bonding/delta-chi.ts`
  2. Engine + legacy import canonical
  3. Remove internal copies

## 3.3 Oxidation state
- Duped between lib/solvers/legacy examples
- Fix:
  1. Canonical: `src/lib/chem/oxidation-state.ts`
  2. Provide minimal API for school tasks with explicit special-case flags

---

# 4. Safety net: golden tests

```mermaid
flowchart TB
  Fixtures --> ChemLibTest[ChemLib unit tests]
  Fixtures --> EngineAdapterTest[Engine adapter parity tests]
  EngineAdapterTest --> LegacyParity[Optional: legacy vs engine parity during migration]
```

---

# 5. Definition of done (per algorithm)
- Only one implementation remains.
- Engine/legacy refer to chemlib.
- Tests cover common + edge cases.
- Old code removed or reduced to adapters.
