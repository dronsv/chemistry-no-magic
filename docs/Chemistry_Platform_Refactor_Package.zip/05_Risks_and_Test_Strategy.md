# Refactor Risks & Test Strategy
Generated: 2026-02-26

## Key risks
1. Behavior regressions when removing duplicated implementations.
2. Silent drift between legacy generators and engine templates during migration.
3. Locale regressions due to prompt template or morphology changes.
4. Exam stability: breaking topic_mapping or task banks.

---

# 1. Testing layers

```mermaid
flowchart TB
  U[Unit tests: src/lib/chem] --> P[Parity tests: engine solver adapters]
  P --> M[Migration parity: legacy vs engine templates]
  M --> I[Integration: build pipeline + integrity validators]
  I --> E[End-to-end smoke: practice + exam flows]
```

## 1.1 Unit tests (ChemLib)
- Fast, deterministic
- Fixtures: known inputs from curriculum tasks

## 1.2 Adapter parity tests (Engine solvers)
- Ensure engine solver output equals chemlib output for same inputs

## 1.3 Migration parity tests (Legacy vs Engine)
- Temporary; removed after migration completion

## 1.4 Build/integrity tests
- Keep existing validators + cross-ref integrity
- Add targeted checks only when new contracts appear

---

# 2. Rollout control
- Feature flags per competency/route
- Shadow mode:
  - engine generates alongside legacy
  - only legacy shown
  - diffs logged in dev/test

---

# 3. Acceptance criteria for a migration PR
- No diffs in canonical fixture set OR diffs documented and justified
- No breakage in exam mode
- BKT event semantics unchanged: (competencyId, correct, hintUsed)

---

# 4. “Do not touch” list (until scale forces it)
- topic_mapping.json
- existing competency_map hints in templates
- BKT engine interface
