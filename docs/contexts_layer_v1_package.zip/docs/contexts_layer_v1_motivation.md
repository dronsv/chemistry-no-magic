# Context Layer v1 — Motivation and Architectural Rationale

## 1. Problem

Chemistry ontology must distinguish between:

- Substance (H2SO4, CO2, NaCl)
- Physical context (solid CO2, molten NaCl, solution of H2SO4)
- Mixture (aqua regia)
- Lexical term ("dry ice", "царская водка")

Without separation, ontology becomes overloaded with artificial entities.

---

## 2. Architectural Principle

Substance = intrinsic chemical identity  
Context = physical/structural state or mixture  
Term = language label  

Context objects are language-neutral.  
Terms are overlays.

---

## 3. Examples

### Dry Ice

Context:
phase_form | sub:CO2 | s

RU term: "сухой лёд"  
EN term: "dry ice"

Fallback (no term): CO2 (solid)

---

### Aqua Regia

Context:
mixture | HCl(aq)*3 + HNO3(aq)*1

RU: царская водка  
EN: aqua regia

---

### Concentrated Sulfuric Acid

Context template:
solution | H2SO4 in H2O | 90–98%

---

## 4. Benefits

- Multilingual robustness
- Reverse lookup capability
- Clean task engine integration
- Scalable to melts and mixtures
- Future-proof knowledge graph foundation
