# Allotropes & Materials — Modeling Notes (v1.1)

## 1. Why not `contexts/`?

`contexts/` describes **state / medium / composition context**:
- phase form (solid CO2)
- solution templates (conc. H2SO4)
- mixtures (aqua regia)
- melts (molten NaCl)

Allotropes (diamond vs graphite) are **structural variants** of the same chemical composition.
They should not be modeled as "context", otherwise the meaning of contexts gets diluted.

---

## 2. Chosen representation: `substance_variant`

We add `variants/substance_variants.v1.json` with entities like:

- `subvar:C_diamond` (formula C, allotrope)
- `subvar:C_graphite` (formula C, allotrope)
- `subvar:P_white` (formula P4, allotrope)
- `subvar:P_red` (formula P, allotrope-like school notation)

Each variant:
- points to a base substance (`sub:C` or `sub:P`)
- has `variant_type`
- may override `formula` for school tasks
- has `canonical_key` for reverse lookup and dedup

---

## 3. "Coal" note

In real chemistry, coal/charcoal are mixtures/materials.
In school tasks, "уголь" is often treated as **amorphous carbon (C)** with roles:
- reducing agent
- adsorbent

So we model it as `subvar:C_coal` (variant of `sub:C`), not as a mixture, for Phase 1.
If needed, later we can introduce a `material/mixture` representation for realistic composition.

---

## 4. Term bindings

`term_bindings.v1.json` now supports:
- `context`
- `context_template`
- `substance_variant`

This allows user-facing names ("алмаз") to resolve to the correct ontology entity,
and enables tasks like:
- "Формула белого фосфора?" → P4
- "Какая модификация углерода проводит ток?" → graphite
